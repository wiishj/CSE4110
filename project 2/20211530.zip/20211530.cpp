#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "mysql.h"

#pragma comment(lib, "libmysql.lib")

const char* host = "localhost";
const char* user = "root";
const char* pw = "Gmlwls123!";
const char* db = "project2";

int main(void) {

	MYSQL* connection = NULL;
	MYSQL conn;
	MYSQL_RES* sql_result;
	MYSQL_ROW sql_row;
	int type;

	/* connection error handling */
	if (mysql_init(&conn) == NULL)
		printf("mysql_init() error!");

	connection = mysql_real_connect(&conn, host, user, pw, db, 3306, (const char*)NULL, 0);
	if (connection == NULL)
	{
		printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
		return 1;
	}

	else
	{
		printf("Connection Succeed\n\n");

		if (mysql_select_db(&conn, db))
		{
			printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
			return 1;
		}
		
		FILE* fp = fopen("20211530_1.txt", "r");
		if (fp == NULL) {
			printf("20211530_1.txt doesn't exist\n");
			return 1;
		}

		char crud[500];
		while (!feof(fp)) {
			fgets(crud, sizeof(crud), fp);
			mysql_query(connection, crud);
			//printf("error check : %d\n", mysql_query(connection, crud));
		}
		fclose(fp);

		while (1) {
			printf("------- SELECT QUERY TYPES -------\n\n");
			printf("\t1. TYPE I\n");
			printf("\t2. TYPE II\n");
			printf("\t3. TYPE III\n");
			printf("\t4. TYPE IV\n");
			printf("\t5. TYPE V\n");
			printf("\t0. QUIT\n");
			printf("----------------------------------\n");
			printf("\n");
			printf("Select tye : ");
			scanf("%d", &type);
			
			if (!type) {
				printf("\n---- Exit the program ----\n");
				break;
			}
			else if (type == 1) {
				int sub_type;
				char traffic[10];
				printf("\n---- TYPE I ----\n");
				printf("Enter the traffic ID you want to check : ");
				scanf("%s", traffic);
				printf("\n");
				printf("\n---- SUBTYPES IN TYPE I ----\n");
				printf("1. TYPE I-1.\n");
				printf("2. TYPE I-2.\n");
				printf("3. TYPE I-3.\n");
				
				printf("\nSelect subtype : ");
				scanf("%d", &sub_type);
				
				if (sub_type == 1) {
					printf("\n---- TYPE I-1 ----\n");
					printf("** Find all customer who had a package on the truck %s at the time of the crash **\n\n", traffic);
					printf("\n");

					char tmp[10] = "";
					char query11[300] = "select distinct P.customer_id from package P, tracking T where P.package_id=T.package_id and T.vehicle_id=";
					strcat(query11, traffic); strcat(query11, " and T.crash='yes'");
					int state11 = 0;
					state11 = mysql_query(connection, query11);
					if (state11 == 0)
					{
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("customer_id : %s \n", sql_row[0]);
						}
						mysql_free_result(sql_result);
					}
					printf("\n\n");
				}
				else if (sub_type == 2) {
					printf("\n---- TYPE I-2 ----\n");
					printf("** Find all recipients who had a package on that truck %s at the time of the crash **\n\n", traffic);

					char tmp[10] = "";
					char query12[300] = "select distinct P.r_name from Package as P, tracking as T where P.package_id=T.package_id and T.vehicle_id=";
					strcat(query12, traffic); strcat(query12, " and T.crash='yes'");
					int state12 = 0;
					state12 = mysql_query(connection, query12);
					if (state12 == 0)
					{	
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("recipient name : %s \n", sql_row[0]);
						}
						mysql_free_result(sql_result);
					}
					printf("\n\n");
				}
				else if (sub_type == 3) {
					printf("\n---- TYPE I-3 ----\n");
					printf("** Find the last successful delivery by that truck prior to the crash **\n\n");

					char query13[300] = "select distinct T1.tracking_time, T1.package_id from tracking T1, Package P where T1.location=P.r_address and T1.tracking_time= (select max(T2.tracking_time) from tracking T2 where T1.package_id=T2.package_id and vehicle_id=";
					strcat(query13, traffic);
					strcat(query13, ")");
					char date[100] = "";
					
					int state13 = 0;
					state13 = mysql_query(connection, query13);
					if (state13 == 0)
					{
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							strcat(date, sql_row[0]);
							printf("last successful time : %s\n", sql_row[0]);
							printf("last successful delivery : %s\n", sql_row[1]);
						}
						mysql_free_result(sql_result);
					}
					printf("\n\n");
				}
			}
			else if (type == 2) {
				char year[5];
				printf("\n---- TYPE II ----\n");
				printf("** Find the customer who has shipped the most packages in certain year **\n\n");
				printf("Which year? (yyyy format) : ");
				scanf("%s", year);
				printf("\n");

				char query2[300] = "with T(c, id) as (select count(customer_id), customer_id from pay where year(paid_at)=";
				strcat(query2, year);
				strcat(query2, " group by customer_id) select id, c, C.c_name from T, customer C where c = (select max(c) from T) and C.customer_id=id ");
				
				int state2 = 0;
				state2 = mysql_query(connection, query2);
				if (state2 == 0)
				{
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("customer_id : %s\ncustomer_name : %s\ncount : %s\n", sql_row[0], sql_row[2], sql_row[1]);
					}
					mysql_free_result(sql_result);
				}
				printf("\n\n");
		
			}
			else if (type == 3) {
				char year[5];
				printf("\n---- TYPE III ----\n");
				printf("** Find the customer who has spent the most money on shipping in the past year **\n\n");
				printf("Which year? (yyyy format) : ");
				scanf("%s", year);
				printf("\n");

				char query3[300] = "with T(c, id) as (select sum(B.amount), P.customer_id from bill B, pay P where P.bill_id=B.bill_id and year(paid_at)= ";
				strcat(query3, year);
				strcat(query3, " group by customer_id) select id, c, C.c_name from T, customer C where c = (select max(c) from T) and id=C.customer_id");
				
				int state3 = 0;
				state3 = mysql_query(connection, query3);
				if (state3 == 0)
				{
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("customer_id : %s\ncustomer name : %s \namount : %s\n", sql_row[0], sql_row[2], sql_row[1]);
					}
					mysql_free_result(sql_result);
				}
				printf("\n\n");
			
			}
			else if (type == 4) {
				printf("\n---- TYPE IV ----\n");
				printf("** Find the packages that were not delivered within the promised time **\n\n");
				printf("\n");

				char query4[300] = "select P.package_id from tracking T, package P where T.package_id = P.package_id and T.location=P.r_address and T.tracking_time>P.estimated_time";

				int state4 = 0;
				state4 = mysql_query(connection, query4);
				if (state4 == 0)
				{
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("package_id : %s\n", sql_row[0]);
					}
					mysql_free_result(sql_result);
				}
				printf("\n\n");
			}
			else if (type == 5) {
				int sub_type;
				char year[4];
				char month[4];
				char name[20];
				printf("\n---- TYPE V ----\n");
				printf("** Generate the bill for each customer for the past month **\n\n");
				printf("Enter the customer name : ");
				scanf("%s", name);
				printf("Which year? (yyyy format) : ");
				scanf("%s", year);
				printf("Which month? (mm format) : ");
				scanf("%s", month);
				printf("\n\n---- SUBTYPES IN TYPE I ----\n");
				printf("1. TYPE V-1 : A simple bill: customer, address, and amount owed.\n");
				printf("2. TYPE V-2 : A bill listing charges by type of service.\n");
				printf("3. TYPE IV-3 : An itemize billing listing each individual shipment and the charges for it.\n");
				printf("\nSelect subtype : ");
				scanf("%d", &sub_type);
				printf("\n");

				if (sub_type == 1) {
					
					

					char query51[300] = "select C.customer_id, B.b_address , sum(B.amount) from customer C, pay P, bill B where C.customer_id=P.customer_id and P.bill_id=B.bill_id and year(B.b_date)=";
					strcat(query51, year);
					strcat(query51, " and month(B.b_date)=");
					strcat(query51, month);
					strcat(query51, " and C.c_name='");
					strcat(query51, name); strcat(query51, "'"); 
					strcat(query51, "group by C.customer_id, B.b_address");
					
					int state51 = 0;
					state51 = mysql_query(connection, query51);
					if (state51 == 0)
					{
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("customer name : %s\ncustomer id : %s\naddress(billing) : %s\namount : %s\n", name, sql_row[0], sql_row[1], sql_row[2]);
							printf("\n");
						}
						mysql_free_result(sql_result);
					}
					printf("\n\n");
				}
				else if (sub_type == 2) {
					char query52[300]="select P.package_id, S.pkg_content, S.pkg_type, S.pkg_weight, S.timeline, B.amount from service S, package P, customer C, bill B where P.svc_id=S.svc_id and C.customer_id=P.customer_id and B.package_id=P.package_id and year(B.b_date)=";
					strcat(query52, year);
					strcat(query52, " and month(B.b_date)=");
					strcat(query52, month);
					strcat(query52, " and C.c_name='");
					strcat(query52, name); strcat(query52, "'");
					
					int state52 = 0;
					state52 = mysql_query(connection, query52);
					if (state52 == 0)
					{
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("customer name : %s\npackage_id : %s\npackage content : %s\n", name, sql_row[0], sql_row[1]);
							printf("(includes _a : oversea shipping, includes _h : hazard content)\n");
							printf("package_type : %s\npackage_weight : %s\ntimeline : %s\namount : %s\n", sql_row[2], sql_row[3], sql_row[4], sql_row[5]);
							printf("\n");
						}
						mysql_free_result(sql_result);
					}
					printf("\n\n");
				}
				else if (sub_type == 3) {
					char query53[300] = "select B.package_id, P.paid_at, P.method, B.amount from customer C, pay P, bill B where C.customer_id=P.customer_id and P.bill_id=B.bill_id and year(B.b_date)=";
					strcat(query53, year);
					strcat(query53, " and month(B.b_date)=");
					strcat(query53, month);
					strcat(query53, " and C.c_name='");
					strcat(query53, name); strcat(query53, "'");

					int state53 = 0;
					state53 = mysql_query(connection, query53);
					if (state53 == 0)
					{
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("customer name : %s\npackage id : %s\npaid at : %s\npayment method : %s\namount : %s\n",name, sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
							printf("\n");
						}
						mysql_free_result(sql_result);
					}
					printf("\n\n");
				}
				char query2[300] = " ";

			}
		}
		mysql_close(connection);
	}
	char d[500];
	FILE* fp = fopen("20211530_2.txt", "r");
	if (fp != NULL) {
		while (!feof(fp)) {
			fgets(d, sizeof(d), fp);
			mysql_query(connection, d);
		}
		fclose(fp);
	}
	return 0;
}





/*

	printf("------- SELECT QUERY TYPES -------\n\n");
	printf("\t1. TYPE 1\n");
	printf("\t2. TYPE 2\n");
	printf("\t3. TYPE 3\n");
	printf("\t4. TYPE 4\n");
	printf("\t5. TYPE 5\n");
	printf("\t6. TYPE 6\n");
	printf("\t7. TYPE 7\n");
	printf("\t0. QUIT\n");
	//printf("----------------------------------\n");
	printf("\n\n");
	printf("---- TYPE 5 ----\n\n");
	printf("** Find the top k brands by unit sales by the year**\n");
	printf(" Which K? : 3\n");

	return 0;

}
*/